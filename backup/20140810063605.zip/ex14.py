#!/usr/bin/python
#Filename: ex14.py
#Description: backup files

import os
import time

source = '.'

target_dir ='/home/geekle/Programming/backup/'

target = target_dir+time.strftime('%Y%m%d%H%M%S') + '.zip'

zip_command = "zip -r '%s' '%s'" %(target, source)

if os.system(zip_command) == 0:
	print 'Successful backup to', target
else:
	print 'Backup failed'
