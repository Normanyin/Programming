#!/usr/bin/python

if __name__ == '__main__':
	print 'this program is being run by itself'
else:
	print 'I am being imported from another module'
