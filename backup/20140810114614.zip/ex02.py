print "How old are you?",
age = raw_input()

print "How tall are you?",
height = raw_input()

print "How much do you weigh?",
weight = raw_input()

print "So, you're %r old, %r tall tall and %r heavy." %(age, height, weight)

print "The second method"

age = raw_input("How old are you?")

print "So you're %r old" % age
