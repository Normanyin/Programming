#!/usr/bin/python
#Filename: ex12.py

import sys

print 'The command line argument are:'

for i in sys.argv:
	print i

print '\n\nThe pythonpath is', sys.path, '\n'
